# Nome: Wallyson lopes Pereira
# TRABALHO: Comparação de 3 algoritmos de classificação
# Algoritmos: k-Nearest Neighbors (kNN), Árvore de Decisão e Regressão Logística
# Base de dados: emails.csv (classificação de Spam x Não Spam)


# 0. IMPORTAÇÃO DAS BIBLIOTECAS
import pandas as pd                       # manipulação de tabelas (dataframes)
import matplotlib.pyplot as plt           # criação de gráficos
import seaborn as sns                     # gráficos estatísticos (heatmaps, etc.)

from sklearn.model_selection import train_test_split      # separar treino/teste
from sklearn.preprocessing import StandardScaler, LabelEncoder  # normalização e codificação
from sklearn.impute import SimpleImputer                  # tratamento de dados faltantes

# Os três algoritmos de classificação pedidos no trabalho:
from sklearn.neighbors import KNeighborsClassifier        # 1) kNN
from sklearn.tree import DecisionTreeClassifier           # 2) Árvore de Decisão
from sklearn.linear_model import LogisticRegression       # 3) Regressão Logística

from sklearn.metrics import (
    accuracy_score,                     # acurácia geral
    precision_recall_fscore_support,    # precisão, recall e f1 por classe
    confusion_matrix,                   # matriz de confusão
    roc_curve,                          # pontos da curva ROC
    auc,                                # área sob a curva ROC
)


# 1. COLETA DE DADOS
# Lemos o arquivo CSV que contém os e-mails já transformados em contagem
# de palavras (cada coluna é uma palavra, cada linha é um e-mail).
dados = pd.read_csv("emails.csv")

# A coluna "Email No." é apenas um identificador (ex: "Email 1", "Email 2"...)
# e não ajuda o modelo a aprender padrões, então é removida.
dados = dados.drop("Email No.", axis=1)

print("Formato da base de dados (linhas, colunas):", dados.shape)
print("\nPrimeiras linhas da base:")
print(dados.head())


# 2. PRÉ-PROCESSAMENTO DE DADOS

#3 ELEMENTOS FALTANTES -------------------------------------------------
# Verificamos se existem valores faltantes (NaN) em alguma coluna.
print("\nValores faltantes por coluna (somatório):")
print(dados.isnull().sum().sum(), "valores faltantes no total")

# Caso existam valores faltantes, preenchemos:
# - colunas numéricas: com a MÉDIA da coluna (estratégia comum p/ contagens)
# - colunas categóricas (texto): com o valor mais frequente (moda)
colunas_numericas = dados.select_dtypes(include=["int64", "float64"]).columns
colunas_categoricas = dados.select_dtypes(include=["object"]).columns

if dados[colunas_numericas].isnull().sum().sum() > 0:
    imputer_num = SimpleImputer(strategy="mean")
    dados[colunas_numericas] = imputer_num.fit_transform(dados[colunas_numericas])

if len(colunas_categoricas) > 0 and dados[colunas_categoricas].isnull().sum().sum() > 0:
    imputer_cat = SimpleImputer(strategy="most_frequent")
    dados[colunas_categoricas] = imputer_cat.fit_transform(dados[colunas_categoricas])

#
# Se houver colunas categóricas (texto) entre as variáveis independentes,
# elas precisam ser convertidas em números, pois os modelos só trabalham
# com valores numéricos. Usamos o LabelEncoder para isso.
for coluna in colunas_categoricas:
    if coluna != "Prediction":  # a coluna alvo é tratada separadamente, se for texto
        le = LabelEncoder()
        dados[coluna] = le.fit_transform(dados[coluna].astype(str))

# 2.3 SEPARAÇÃO ENTRE VARIÁVEIS INDEPENDENTES (X) E VARIÁVEL ALVO (y) -----
# X = todas as colunas de contagem de palavras (variáveis independentes)
# y = "Prediction" -> 0 = não é spam, 1 = é spam (variável alvo, categórica)
X = dados.drop("Prediction", axis=1)
y = dados["Prediction"]

# Se a variável alvo (y) ainda estiver em formato de texto, convertemos para número
if y.dtype == "object":
    le_alvo = LabelEncoder()
    y = le_alvo.fit_transform(y)

# 2.4 SEPARAÇÃO EM TREINO E TESTE -----------------------------------------
# Reservamos 80% dos dados para treinar os modelos e 20% para testar.
# random_state=42 garante que a divisão seja sempre a mesma (reprodutível).
X_treino, X_teste, y_treino, y_teste = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 2.5 NORMALIZAÇÃO ---------------------------------------------------------
# kNN e Regressão Logística são sensíveis à escala dos dados (colunas com
# valores muito grandes "dominam" colunas com valores pequenos). Por isso,
# padronizamos as variáveis para que tenham média 0 e desvio padrão 1.
# A Árvore de Decisão não precisa de normalização, mas usar os dados
# normalizados não prejudica seu desempenho.
scaler = StandardScaler()
X_treino_escalado = scaler.fit_transform(X_treino)  # ajusta e transforma o treino
X_teste_escalado = scaler.transform(X_teste)        # aplica a mesma transformação no teste


# -----------------------------------------------------------------------
# 3. IMPLEMENTAÇÃO E TREINO DOS TRÊS ALGORITMOS
# -----------------------------------------------------------------------

# 3.1 kNN (k-Nearest Neighbors) -------------------------------------------
# Classifica um e-mail observando a classe dos "k" e-mails mais parecidos
# (vizinhos) com ele no conjunto de treino. Usamos k = 5 (valor padrão comum).
modelo_knn = KNeighborsClassifier(n_neighbors=5)
modelo_knn.fit(X_treino_escalado, y_treino)

# 3.2 Árvore de Decisão ----------------------------------------------------
# Cria uma sequência de perguntas (ex: "a palavra X aparece mais de N vezes?")
# que divide os dados até chegar a uma decisão final (spam ou não spam).
modelo_arvore = DecisionTreeClassifier(random_state=42)
modelo_arvore.fit(X_treino, y_treino)  # árvore não exige dados normalizados

# 3.3 Regressão Logística --------------------------------------------------
# Calcula a probabilidade de um e-mail ser spam com base em uma combinação
# linear das variáveis, passada por uma função logística (sigmoide).
modelo_logistica = LogisticRegression(max_iter=1000)
modelo_logistica.fit(X_treino_escalado, y_treino)

# Guardamos os 3 modelos em um dicionário para facilitar a avaliação em loop
modelos = {
    "kNN": (modelo_knn, X_teste_escalado),
    "Árvore de Decisão": (modelo_arvore, X_teste),
    "Regressão Logística": (modelo_logistica, X_teste_escalado),
}


# 4. AVALIAÇÃO DOS MODELOS
nomes_classes = ["Não Spam", "Spam"]
resultados = []          # vai guardar as métricas de cada modelo (para comparar depois)
matrizes_confusao = {}   # vai guardar a matriz de confusão de cada modelo
curvas_roc = {}          # vai guardar fpr/tpr/auc de cada modelo

for nome_modelo, (modelo, X_teste_usado) in modelos.items():
    # Previsões de classe (0 ou 1)
    y_pred = modelo.predict(X_teste_usado)

    # Probabilidade da classe "1" (spam), usada para a curva ROC
    y_proba = modelo.predict_proba(X_teste_usado)[:, 1]

    # Métricas principais
    acuracia = accuracy_score(y_teste, y_pred)
    precisao, recall, f1, suporte = precision_recall_fscore_support(
        y_teste, y_pred, labels=[0, 1]
    )

    # Médias ponderadas (consideram o tamanho de cada classe)
    precisao_pond, recall_pond, f1_pond, _ = precision_recall_fscore_support(
        y_teste, y_pred, labels=[0, 1], average="weighted"
    )

    # Guardamos um resumo para a tabela comparativa final
    resultados.append({
        "Modelo": nome_modelo,
        "Acurácia": acuracia,
        "Precisão (Spam)": precisao[1],
        "Recall (Spam)": recall[1],
        "F1-Score (Spam)": f1[1],
        "Precisão (pond.)": precisao_pond,
        "Recall (pond.)": recall_pond,
        "F1-Score (pond.)": f1_pond,
    })

    # Matriz de confusão deste modelo
    matrizes_confusao[nome_modelo] = confusion_matrix(y_teste, y_pred)

    # Pontos da curva ROC e área sob a curva (AUC) deste modelo
    fpr, tpr, _ = roc_curve(y_teste, y_proba)
    curvas_roc[nome_modelo] = (fpr, tpr, auc(fpr, tpr))

    # Impressão detalhada no terminal
    print(f"\n===== {nome_modelo} =====")
    print(f"Acurácia: {acuracia:.4f}")
    print(f"{'':18}{'precisão':>10}{'recall':>10}{'f1-score':>10}{'suporte':>10}")
    for nome_classe, p, r, f, s in zip(nomes_classes, precisao, recall, f1, suporte):
        print(f"{nome_classe:18}{p:10.2f}{r:10.2f}{f:10.2f}{s:10d}")


# 5. COMPARAÇÃO DE DESEMPENHO ENTRE OS MODELOS
tabela_comparativa = pd.DataFrame(resultados).set_index("Modelo")
print("\n\n===== TABELA COMPARATIVA FINAL =====")
print(tabela_comparativa.round(4))

# Identifica automaticamente o modelo com maior F1-Score ponderado,
# métrica que equilibra precisão e recall (boa escolha quando as classes
# têm tamanhos diferentes, como costuma ocorrer em detecção de spam).
melhor_modelo = tabela_comparativa["F1-Score (pond.)"].idxmax()
print(f"\nMelhor modelo (baseado no F1-Score ponderado): {melhor_modelo}")


# 6. GRÁFICOS PARA AVALIAR E COMPARAR OS MODELOS

# 7 Matrizes de confusão dos 3 modelos, lado a lado --------------------
fig, eixos = plt.subplots(1, 3, figsize=(15, 4))
for eixo, (nome_modelo, matriz) in zip(eixos, matrizes_confusao.items()):
    sns.heatmap(
        matriz, annot=True, fmt="d", cmap="Blues",
        xticklabels=nomes_classes, yticklabels=nomes_classes, ax=eixo
    )
    eixo.set_title(nome_modelo)
    eixo.set_xlabel("Classe Prevista")
    eixo.set_ylabel("Classe Real")
plt.tight_layout()
plt.savefig("matrizes_confusao_comparativo.png", dpi=150)
plt.close()

# 8 Curvas ROC dos 3 modelos no mesmo gráfico ---------------------------
fig, ax = plt.subplots(figsize=(6, 5))
for nome_modelo, (fpr, tpr, roc_auc) in curvas_roc.items():
    ax.plot(fpr, tpr, lw=2, label=f"{nome_modelo} (AUC = {roc_auc:.2f})")
ax.plot([0, 1], [0, 1], color="gray", lw=1, linestyle="--", label="Modelo Aleatório")
ax.set_xlabel("Taxa de Falsos Positivos")
ax.set_ylabel("Taxa de Verdadeiros Positivos")
ax.set_title("Curvas ROC - Comparação entre Modelos")
ax.legend(loc="lower right")
plt.tight_layout()
plt.savefig("curvas_roc_comparativo.png", dpi=150)
plt.close()

#8
metricas_grafico = tabela_comparativa[
    ["Acurácia", "Precisão (pond.)", "Recall (pond.)", "F1-Score (pond.)"]
]
fig, ax = plt.subplots(figsize=(8, 5))
metricas_grafico.plot(kind="bar", ax=ax, rot=0)
ax.set_ylim(0, 1.1)
ax.set_ylabel("Valor")
ax.set_title("Comparação de Métricas entre os 3 Modelos")
ax.legend(loc="lower right")
plt.tight_layout()
plt.savefig("comparacao_metricas_modelos.png", dpi=150)
plt.close()

print("\nGráficos salvos:")
print("- matrizes_confusao_comparativo.png")
print("- curvas_roc_comparativo.png")
print("- comparacao_metricas_modelos.png")


# 10 RELATÓRIO SINTÉTICO (resumo escrito para incluir na entrega)

"""
RELATÓRIO SINTÉTICO

Base de dados: emails.csv (contagem de palavras por e-mail; alvo
"Prediction": 1 = Spam, 0 = Não Spam).

Pré-processamento: remoção do identificador "Email No.", tratamento de
valores faltantes (se houver), conversão de categóricas em numéricas,
divisão treino/teste (80/20, estratificada) e normalização (StandardScaler)
para kNN e Regressão Logística.

Modelos treinados: kNN (k=5), Árvore de Decisão e Regressão Logística.

Comparação: os três modelos foram avaliados pelas métricas de Acurácia,
Precisão, Recall e F1-Score, e comparados visualmente nos gráficos de
matriz de confusão, curva ROC e barras de métricas.

Conclusão: o melhor modelo é apontado automaticamente pelo script
(variável "melhor_modelo", baseada no F1-Score ponderado). Em geral,
Regressão Logística e Árvore de Decisão tendem a performar bem nesse tipo
de dado, enquanto o kNN pode sofrer um pouco com a alta dimensionalidade.
Os valores exatos de cada métrica devem ser consultados na tabela
comparativa impressa ao final da execução.
"""